
import React from 'react';
import { ResumeData } from '../../types';
import { parseExperienceString } from './utils';

interface CreativeResumeProps {
  data: ResumeData;
}

export const CreativeResume: React.FC<CreativeResumeProps> = ({ data }) => {
  const experienceItems = parseExperienceString(data.experience);
  const skillsList = data.skills ? data.skills.split(',').map(s => s.trim()) : [];

  return (
    <div className="flex flex-col md:flex-row bg-white text-slate-700 min-h-[842px] creative-resume"> {/* A4 height approx */}
      {/* Sidebar */}
      <aside className="md:w-1/3 bg-dark text-white p-8 sidebar">
        <div className="text-center md:text-left">
          <h1 className="text-3xl font-bold mb-1">{data.fullName}</h1>
          <p className="text-lg text-primary mb-8">{data.jobTitle}</p>
        </div>

        <section className="mb-8">
          <h2 className="text-xl font-semibold text-primary border-b-2 border-primary pb-1 mb-3 uppercase tracking-wider">Contact</h2>
          <div className="space-y-1 text-sm">
            {data.contact.email && <p><a href={`mailto:${data.contact.email}`} className="hover:text-primary">{data.contact.email}</a></p>}
            {data.contact.phone && <p>{data.contact.phone}</p>}
            {data.contact.linkedin && <p><a href={`https://${data.contact.linkedin}`} target="_blank" rel="noopener noreferrer" className="hover:text-primary">{data.contact.linkedin}</a></p>}
            {data.contact.portfolio && <p><a href={`https://${data.contact.portfolio}`} target="_blank" rel="noopener noreferrer" className="hover:text-primary">{data.contact.portfolio}</a></p>}
            {data.contact.address && <p>{data.contact.address}</p>}
          </div>
        </section>

        {skillsList.length > 0 && (
          <section>
            <h2 className="text-xl font-semibold text-primary border-b-2 border-primary pb-1 mb-3 uppercase tracking-wider">Skills</h2>
            <ul className="space-y-1 text-sm list-inside list-disc marker:text-primary">
              {skillsList.map((skill, index) => <li key={index}>{skill}</li>)}
            </ul>
          </section>
        )}
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 bg-slate-50">
        {data.summary && (
          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-dark border-b-2 border-primary pb-2 mb-3 uppercase tracking-wider">Profile</h2>
            <p className="text-slate-600 leading-relaxed whitespace-pre-line">{data.summary}</p>
          </section>
        )}

        {experienceItems.length > 0 && (
          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-dark border-b-2 border-primary pb-2 mb-4 uppercase tracking-wider">Experience</h2>
            {experienceItems.map((item, index) => (
              <div key={index} className="mb-5">
                <h3 className="text-lg font-semibold text-slate-800">{item.jobTitle || item.rawFirstLine}</h3>
                {item.company && <p className="text-md font-medium text-primary">{item.company} <span className="text-slate-500 text-sm ml-2">{item.date}</span></p>}
                {item.responsibilities.length > 0 && (
                  <ul className="list-disc list-inside mt-1 text-slate-600 space-y-1 pl-2">
                    {item.responsibilities.map((resp, i) => <li key={i}>{resp}</li>)}
                  </ul>
                )}
              </div>
            ))}
          </section>
        )}

        {(data.education.degree || data.education.university) && (
          <section>
            <h2 className="text-2xl font-semibold text-dark border-b-2 border-primary pb-2 mb-3 uppercase tracking-wider">Education</h2>
            <div className="mb-3">
              <h3 className="text-lg font-semibold text-slate-800">{data.education.degree}{data.education.field && ` in ${data.education.field}`}</h3>
              <p className="text-md font-medium text-primary">{data.education.university} <span className="text-slate-500 text-sm ml-2">{data.education.gradYear && `(${data.education.gradYear})`}</span></p>
              {data.education.details && <p className="text-slate-600 text-sm mt-1">{data.education.details}</p>}
            </div>
          </section>
        )}
      </main>
    </div>
  );
};
