
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="text-center mb-8 p-6 bg-white rounded-lg shadow-lg">
      <h1 className="text-4xl font-bold text-dark mb-2">Smart Resume Generator <span className="text-primary">AI</span></h1>
      <p className="text-slate-600 text-lg">Create professional resumes with AI-powered enhancements</p>
    </header>
  );
};
