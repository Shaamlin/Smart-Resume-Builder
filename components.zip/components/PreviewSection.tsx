
import React, { forwardRef } from 'react';
import { ResumeData, TemplateOption } from '../types';
import { ModernResume } from './resume_templates/ModernResume';
import { ClassicResume } from './resume_templates/ClassicResume';
import { CreativeResume } from './resume_templates/CreativeResume';

interface PreviewSectionProps {
  resumeData: ResumeData;
  selectedTemplate: TemplateOption;
}

export const PreviewSection = forwardRef<HTMLDivElement, PreviewSectionProps>(({ resumeData, selectedTemplate }, ref) => {
  const renderTemplate = () => {
    switch (selectedTemplate) {
      case TemplateOption.MODERN:
        return <ModernResume data={resumeData} />;
      case TemplateOption.CLASSIC:
        return <ClassicResume data={resumeData} />;
      case TemplateOption.CREATIVE:
        return <CreativeResume data={resumeData} />;
      default:
        return <ModernResume data={resumeData} />;
    }
  };

  return (
    <section className="lg:w-3/5">
      <h2 className="text-2xl font-bold text-dark mb-6 hidden lg:block">Resume Preview</h2>
      <div 
        ref={ref} 
        className="bg-white rounded-lg shadow-xl overflow-auto p-1" 
        style={{ minHeight: 'calc(100vh - 200px)' }} // Ensure it's tall enough
      >
        {/* The actual resume template content will have its own padding */}
        {renderTemplate()}
      </div>
    </section>
  );
});

PreviewSection.displayName = 'PreviewSection';
