
import React from 'react';
import { ResumeData, TemplateOption, ContactInfo, EducationInfo } from '../types';
import { LoadingSpinner } from './LoadingSpinner';

interface InputSectionProps {
  resumeData: ResumeData;
  onDataChange: (section: keyof ResumeData | `contact.${keyof ContactInfo}` | `education.${keyof EducationInfo}`, value: string) => void;
  aiPrompt: string;
  onAiPromptChange: (value: string) => void;
  onGenerateSummary: () => void;
  isGeneratingSummary: boolean;
  selectedTemplate: TemplateOption;
  onTemplateChange: (template: TemplateOption) => void;
  onPrint: () => void;
  onReset: () => void;
}

const FormField: React.FC<{
  label: string;
  id: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  placeholder?: string;
  type?: 'text' | 'email' | 'tel';
  isTextArea?: boolean;
  name: keyof ResumeData | `contact.${keyof ContactInfo}` | `education.${keyof EducationInfo}`;
}> = ({ label, id, value, onChange, placeholder, type = 'text', isTextArea = false, name }) => (
  <div className="mb-4">
    <label htmlFor={id} className="block mb-1.5 font-semibold text-slate-700 text-sm">
      {label}
    </label>
    {isTextArea ? (
      <textarea
        id={id}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        rows={3}
        className="w-full p-2.5 bg-white border border-slate-400 text-slate-800 placeholder-slate-500 rounded-md text-base focus:ring-2 focus:ring-primary focus:border-primary transition-shadow"
      />
    ) : (
      <input
        type={type}
        id={id}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="w-full p-2.5 bg-white border border-slate-400 text-slate-800 placeholder-slate-500 rounded-md text-base focus:ring-2 focus:ring-primary focus:border-primary transition-shadow"
      />
    )}
  </div>
);


export const InputSection: React.FC<InputSectionProps> = ({
  resumeData, onDataChange, aiPrompt, onAiPromptChange, onGenerateSummary,
  isGeneratingSummary, selectedTemplate, onTemplateChange, onPrint, onReset
}) => {
  
  const handleFieldChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    onDataChange(e.target.name as keyof ResumeData | `contact.${keyof ContactInfo}` | `education.${keyof EducationInfo}`, e.target.value);
  };

  const templates = [
    { id: TemplateOption.MODERN, name: 'Modern', color: 'bg-blue-100' },
    { id: TemplateOption.CLASSIC, name: 'Classic', color: 'bg-amber-100' },
    { id: TemplateOption.CREATIVE, name: 'Creative', color: 'bg-purple-100' },
  ];

  return (
    <section className="lg:w-2/5 bg-white p-6 rounded-lg shadow-xl">
      <h2 className="text-2xl font-bold text-dark mb-6">Your Information</h2>

      <FormField label="Full Name" id="fullName" name="fullName" value={resumeData.fullName} onChange={handleFieldChange} placeholder="John Doe" />
      <FormField label="Professional Title" id="jobTitle" name="jobTitle" value={resumeData.jobTitle} onChange={handleFieldChange} placeholder="Software Engineer" />

      <h3 className="text-xl font-semibold text-dark mt-6 mb-3">Contact Information</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4">
        <FormField label="Phone Number" id="phone" name="contact.phone" type="tel" value={resumeData.contact.phone} onChange={handleFieldChange} placeholder="(123) 456-7890" />
        <FormField label="Email" id="email" name="contact.email" type="email" value={resumeData.contact.email} onChange={handleFieldChange} placeholder="john@example.com" />
        <FormField label="LinkedIn" id="linkedin" name="contact.linkedin" value={resumeData.contact.linkedin} onChange={handleFieldChange} placeholder="linkedin.com/in/username" />
        <FormField label="Portfolio/Website" id="portfolio" name="contact.portfolio" value={resumeData.contact.portfolio} onChange={handleFieldChange} placeholder="yourwebsite.com" />
      </div>
      <FormField label="Address (optional)" id="address" name="contact.address" value={resumeData.contact.address} onChange={handleFieldChange} placeholder="City, State" />

      <div className="my-6 p-4 bg-slate-50 rounded-lg border border-slate-200">
        <FormField label="Professional Summary" id="summary" name="summary" value={resumeData.summary} onChange={handleFieldChange} placeholder="Experienced professional with..." isTextArea />
        <div className="mt-3">
          <label htmlFor="aiPrompt" className="block mb-1.5 font-semibold text-slate-700 text-sm">AI Enhancement Prompt (Optional)</label>
          <input
            type="text"
            id="aiPrompt"
            value={aiPrompt}
            onChange={(e) => onAiPromptChange(e.target.value)}
            placeholder="e.g., Highlight my leadership skills"
            className="w-full p-2.5 bg-white border border-slate-400 text-slate-800 placeholder-slate-500 rounded-md text-base mb-2 focus:ring-2 focus:ring-primary focus:border-primary"
          />
          <button
            onClick={onGenerateSummary}
            disabled={isGeneratingSummary}
            className="w-full bg-primary hover:bg-blue-700 text-white font-semibold py-2.5 px-4 rounded-md flex items-center justify-center transition-colors disabled:opacity-70"
          >
            {isGeneratingSummary ? <><LoadingSpinner /> Generating...</> : 'Generate with AI'}
          </button>
        </div>
      </div>

      <FormField label="Work Experience" id="experience" name="experience" value={resumeData.experience} onChange={handleFieldChange} placeholder="Senior Developer, XYZ Company (2020-Present)\n- Led team..." isTextArea />
      
      <h3 className="text-xl font-semibold text-dark mt-6 mb-3">Education Background</h3>
       <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4">
        <FormField label="Degree" id="degree" name="education.degree" value={resumeData.education.degree} onChange={handleFieldChange} placeholder="Bachelor of Science" />
        <FormField label="Field of Study" id="field" name="education.field" value={resumeData.education.field} onChange={handleFieldChange} placeholder="Computer Science" />
        <FormField label="University" id="university" name="education.university" value={resumeData.education.university} onChange={handleFieldChange} placeholder="University of ABC" />
        <FormField label="Graduation Year" id="gradYear" name="education.gradYear" value={resumeData.education.gradYear} onChange={handleFieldChange} placeholder="2019" />
      </div>
      <FormField label="Additional Education Details (GPA, honors, etc.)" id="educationDetails" name="education.details" value={resumeData.education.details} onChange={handleFieldChange} placeholder="GPA: 3.8, Magna Cum Laude" isTextArea />

      <FormField label="Skills" id="skills" name="skills" value={resumeData.skills} onChange={handleFieldChange} placeholder="JavaScript, React, Node.js..." isTextArea />

      <h3 className="text-xl font-semibold text-dark mt-6 mb-3">Choose a Template</h3>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        {templates.map(template => (
          <div
            key={template.id}
            onClick={() => onTemplateChange(template.id)}
            className={`border-2 rounded-lg overflow-hidden cursor-pointer transition-all duration-200 hover:shadow-lg hover:-translate-y-1 ${selectedTemplate === template.id ? 'border-primary ring-2 ring-primary shadow-xl' : 'border-slate-300'}`}
          >
            <div className={`h-32 ${template.color} flex items-center justify-center text-slate-500`}>Template Preview</div>
            <div className="text-center p-3 bg-white font-semibold text-dark">{template.name}</div>
          </div>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mt-8">
        <button onClick={onPrint} className="flex-1 bg-secondary hover:bg-green-700 text-white font-semibold py-3 px-4 rounded-md transition-colors">
          Print as PDF
        </button>
        <button onClick={onReset} className="flex-1 bg-danger hover:bg-red-700 text-white font-semibold py-3 px-4 rounded-md transition-colors">
          Reset Form
        </button>
      </div>
    </section>
  );
};
