
import { ParsedExperienceItem } from '../../types';

export const parseExperienceString = (experience: string): ParsedExperienceItem[] => {
  if (!experience || !experience.trim()) return [];
  
  const items = experience.split(/\n\s*\n/); // Split by one or more newlines, allowing for empty lines between entries

  return items.map(item => {
    const lines = item.split('\n').map(line => line.trim()).filter(line => line);
    if (lines.length === 0) return null;

    const firstLine = lines[0];
    const restLines = lines.slice(1).map(line => line.replace(/^-?\s*/, '')).filter(line => line);

    // Regex to capture: Job Title, Company (Date Range)
    // It's more flexible: (Anything before comma), (Anything before optional parenthesis) (Content in parenthesis if present)
    const companyMatch = firstLine.match(/^(.*?),\s*(.*?)(?:\s*\((.*?)\))?$/);

    if (companyMatch) {
      return {
        jobTitle: companyMatch[1] ? companyMatch[1].trim() : 'N/A',
        company: companyMatch[2] ? companyMatch[2].trim() : 'N/A',
        date: companyMatch[3] ? companyMatch[3].trim() : '',
        responsibilities: restLines,
      };
    } else {
      // Fallback if first line doesn't match the expected Job Title, Company (Date) format
      return {
        jobTitle: '', // Or consider firstLine as jobTitle if no comma
        company: '',
        date: '',
        responsibilities: lines.map(line => line.replace(/^-?\s*/, '')).filter(line => line), // Treat all lines as responsibilities
        rawFirstLine: firstLine 
      };
    }
  }).filter(item => item !== null) as ParsedExperienceItem[];
};
