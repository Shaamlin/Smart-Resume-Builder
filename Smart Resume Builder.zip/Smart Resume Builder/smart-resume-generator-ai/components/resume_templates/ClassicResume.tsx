
import React from 'react';
import { ResumeData } from '../../types';
import { parseExperienceString } from './utils';

interface ClassicResumeProps {
  data: ResumeData;
}

export const ClassicResume: React.FC<ClassicResumeProps> = ({ data }) => {
  const experienceItems = parseExperienceString(data.experience);

  return (
    <div className="p-8 bg-white text-slate-800 font-serif classic-resume">
      {/* Header */}
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold tracking-wider text-dark">{data.fullName.toUpperCase()}</h1>
        <p className="text-xl italic text-slate-700 mt-1">{data.jobTitle}</p>
        <div className="mt-3 text-sm text-slate-600">
          {data.contact.address && <span className="mx-2">{data.contact.address}</span>}
          {data.contact.phone && <span className="mx-2">{data.contact.phone}</span>}
          {data.contact.email && <span className="mx-2"><a href={`mailto:${data.contact.email}`} className="hover:underline">{data.contact.email}</a></span>}
          {data.contact.linkedin && <span className="mx-2"><a href={`https://${data.contact.linkedin}`} target="_blank" rel="noopener noreferrer" className="hover:underline">{data.contact.linkedin}</a></span>}
          {data.contact.portfolio && <span className="mx-2"><a href={`https://${data.contact.portfolio}`} target="_blank" rel="noopener noreferrer" className="hover:underline">{data.contact.portfolio}</a></span>}
        </div>
      </header>

      {/* Summary Section */}
      {data.summary && (
        <section className="mb-6">
          <h2 className="text-lg font-bold bg-dark text-white py-1 px-3 mb-3 tracking-wide">PROFESSIONAL SUMMARY</h2>
          <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-line">{data.summary}</p>
        </section>
      )}

      {/* Experience Section */}
      {experienceItems.length > 0 && (
        <section className="mb-6">
          <h2 className="text-lg font-bold bg-dark text-white py-1 px-3 mb-3 tracking-wide">WORK EXPERIENCE</h2>
          {experienceItems.map((item, index) => (
            <div key={index} className="mb-4">
              <h3 className="text-md font-semibold text-slate-900">{item.jobTitle || item.rawFirstLine}</h3>
              {item.company && <p className="text-sm font-medium text-slate-700">{item.company} {item.date && <span className="italic text-slate-600 ml-2">{item.date}</span>}</p>}
              {item.responsibilities.length > 0 && (
                <ul className="list-disc list-inside mt-1 text-slate-700 text-sm space-y-0.5 pl-2">
                  {item.responsibilities.map((resp, i) => <li key={i}>{resp}</li>)}
                </ul>
              )}
            </div>
          ))}
        </section>
      )}
      
      {/* Education Section */}
      {(data.education.degree || data.education.university) && (
        <section className="mb-6">
          <h2 className="text-lg font-bold bg-dark text-white py-1 px-3 mb-3 tracking-wide">EDUCATION</h2>
          <div className="mb-2">
            <h3 className="text-md font-semibold text-slate-900">{data.education.degree}{data.education.field && ` in ${data.education.field}`}</h3>
            <p className="text-sm font-medium text-slate-700">{data.education.university} {data.education.gradYear && <span className="italic text-slate-600 ml-2">({data.education.gradYear})</span>}</p>
            {data.education.details && <p className="text-slate-700 text-xs mt-0.5">{data.education.details}</p>}
          </div>
        </section>
      )}

      {/* Skills Section */}
      {data.skills && (
        <section>
          <h2 className="text-lg font-bold bg-dark text-white py-1 px-3 mb-3 tracking-wide">SKILLS</h2>
          <p className="text-slate-700 text-sm whitespace-pre-line">{data.skills.split(',').map(skill => skill.trim()).join(' | ')}</p>
        </section>
      )}
    </div>
  );
};
