
import React from 'react';
import { ResumeData } from '../../types';
import { parseExperienceString } from './utils';

interface ModernResumeProps {
  data: ResumeData;
}

export const ModernResume: React.FC<ModernResumeProps> = ({ data }) => {
  const experienceItems = parseExperienceString(data.experience);

  return (
    <div className="p-8 bg-white text-slate-700 modern-resume">
      {/* Header */}
      <header className="flex justify-between items-start mb-10">
        <div>
          <h1 className="text-4xl font-bold text-dark">{data.fullName}</h1>
          <p className="text-xl text-primary">{data.jobTitle}</p>
        </div>
        <div className="text-right text-sm">
          {data.contact.email && <p><a href={`mailto:${data.contact.email}`} className="hover:text-primary">{data.contact.email}</a></p>}
          {data.contact.phone && <p>{data.contact.phone}</p>}
          {data.contact.linkedin && <p><a href={`https://${data.contact.linkedin}`} target="_blank" rel="noopener noreferrer" className="hover:text-primary">{data.contact.linkedin}</a></p>}
          {data.contact.portfolio && <p><a href={`https://${data.contact.portfolio}`} target="_blank" rel="noopener noreferrer" className="hover:text-primary">{data.contact.portfolio}</a></p>}
          {data.contact.address && <p>{data.contact.address}</p>}
        </div>
      </header>

      {/* Summary Section */}
      {data.summary && (
        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-dark border-b-2 border-primary pb-2 mb-3">Professional Summary</h2>
          <p className="text-slate-600 whitespace-pre-line">{data.summary}</p>
        </section>
      )}

      {/* Experience Section */}
      {experienceItems.length > 0 && (
        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-dark border-b-2 border-primary pb-2 mb-4">Work Experience</h2>
          {experienceItems.map((item, index) => (
            <div key={index} className="mb-5">
              <h3 className="text-lg font-semibold text-slate-800">{item.jobTitle || item.rawFirstLine}</h3>
              {item.company && <p className="text-md font-medium text-primary">{item.company} <span className="text-slate-500 text-sm ml-2">{item.date}</span></p>}
              {item.responsibilities.length > 0 && (
                <ul className="list-disc list-inside mt-1 text-slate-600 space-y-1 pl-2">
                  {item.responsibilities.map((resp, i) => <li key={i}>{resp}</li>)}
                </ul>
              )}
            </div>
          ))}
        </section>
      )}

      {/* Education Section */}
      { (data.education.degree || data.education.university) && (
        <section className="mb-8">
          <h2 className="text-2xl font-semibold text-dark border-b-2 border-primary pb-2 mb-3">Education</h2>
          <div className="mb-3">
            <h3 className="text-lg font-semibold text-slate-800">{data.education.degree}{data.education.field && ` in ${data.education.field}`}</h3>
            <p className="text-md font-medium text-primary">{data.education.university} <span className="text-slate-500 text-sm ml-2">{data.education.gradYear && `(${data.education.gradYear})`}</span></p>
            {data.education.details && <p className="text-slate-600 text-sm mt-1">{data.education.details}</p>}
          </div>
        </section>
      )}
      
      {/* Skills Section */}
      {data.skills && (
        <section>
          <h2 className="text-2xl font-semibold text-dark border-b-2 border-primary pb-2 mb-3">Skills</h2>
          <p className="text-slate-600 whitespace-pre-line">{data.skills.split(',').map(skill => skill.trim()).join(' · ')}</p>
        </section>
      )}
    </div>
  );
};
