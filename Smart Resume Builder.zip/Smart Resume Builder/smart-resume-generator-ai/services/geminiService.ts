
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("Gemini API key not found. Please set the process.env.API_KEY environment variable.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "YOUR_API_KEY_HERE" }); // Fallback for environments where process.env is not set up by build tool

const model = 'gemini-2.5-flash-preview-04-17';

export const generateResumeSummary = async (prompt: string): Promise<string> => {
  if (!API_KEY && !ai.apiKey) { // Check if API key is truly missing
     return Promise.reject(new Error("API Key for Gemini not configured. AI features are disabled."));
  }
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: model,
        contents: prompt,
        // Omit thinkingConfig to use default (enabled) for higher quality
    });
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error(`Gemini API request failed: ${error instanceof Error ? error.message : String(error)}`);
  }
};
